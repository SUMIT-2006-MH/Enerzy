# Electro 
Electro is a tool for estimating the elctricity consumption of your home which calculates the total electricity consumption of your home and the electricity consumption of each appliance.
## The idea
- I got the idea for making such application from my geography book.
- A table was made at the end of the chapter "Mineral and power resources" in the Geography book 
- That table encouraged us to collect the data from your neighborhood about their usage of each appliance  and to calculate the total electricity consumption of your home.
- Then I thought 'What if I make a web application that can calculate the electricity consumption of my home?'...
## Running the tool
- To run, you just need to open the index.html file in your browser.
- You can directly preview it from - https://vinayakhanda.github.io/Electro/] (https://vinayakhanda.github.io/Electro/)
## Languages and programming 
- The tool is written in HTML, and JavaScript.
- A little bit of CSS is used to make the design of the disclamier.
- Near about 400 lines of code have been used to make this project (excluding this readme and the license).
## Contents
- [index.html](index.html) - The main page of the project.
- [script.js](script.js) - The main script of the project.
- [objs.txt](objs.txt) - There is nothing for you in this file. its just for my reference 
- [LICENSE](LICENSE) - The license of the project.
- [README.md](README.md) - The readme of the project.
## Special thanks
- I would like to thanks my little Brother for helping me to make this project (who doesnt even knows ABC of programming 😂).
